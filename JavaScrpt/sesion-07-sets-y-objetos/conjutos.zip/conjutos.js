let familia = new Set(['Merche', 'Vicent', 'Mireia', 'Laia', 'Júlia'])

console.log(familia)

familia.add('Vicent')

console.log(familia)

familia.add('JavaScript')

console.log(familia)