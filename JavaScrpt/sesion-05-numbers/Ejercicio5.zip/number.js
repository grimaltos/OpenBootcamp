let altura_cm = 179;
let altura_m = 1.79;
let peso_kg = 92.5;

let r_altura_m = Math.ceil(altura_m);
let r_peso_kg = Math.floor(peso_kg);

console.log(r_altura_m);
console.log(r_peso_kg);

let sonIguales = Number.MAX_VALUE + 1 === Number.MAX_VALUE

console.log(sonIguales)