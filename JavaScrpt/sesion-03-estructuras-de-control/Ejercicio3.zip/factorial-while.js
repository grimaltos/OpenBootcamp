let factorial = 1
let contador = 1

while(contador<10){
    factorial += factorial * contador
    console.log(factorial)
    contador++
}