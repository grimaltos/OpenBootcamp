let nombre = "Vicent"
let apellido = "Grimaltos"

let estudiante =  nombre + ' ' + apellido
let estudianteMayus = estudiante.toUpperCase()
let estudianteMinus = estudiante.toLowerCase()

let numchar = estudiante.length

let primerChar = nombre.charAt(0)
let ultimoChar = apellido.charAt(-1)

let sinEspacios = estudiante.trim()

let incluye = estudiante.includes(nombre)